![preview](https://raw.githubusercontent.com/biplobsd/OneClickRun/master/img/preview.gif)

# OneClickRun <img src="https://hitcounter.pythonanywhere.com/count/tag.svg?url=https%3A%2F%2Fgithub.com%2Fbiplobsd%2FOneClickRun" alt="Hits">

<b>Features:</b><br>
`Jellyfin, aria2, ariang, rclone, rclone WebUI, Netdata, Cloud Commander, 
Ssh, noVnc, filebrowser, SocialFish, L3MON, SayCheese, spotify-downloader, pyLoad, code-server, V2ray, NoMachine ...`


# Usage
Click on the "Open in Colab" button.
<a href="https://colab.research.google.com/github/biplobsd/OneClickRun/blob/master/OneClickRun.ipynb" target="_parent\"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/></a>

### Our telegram group
<center><a href="https://t.me/torrentToGM"><img src='https://i.imgur.com/CLg6blO.png' height="70" alt="Telegram Group"/></a></center>

